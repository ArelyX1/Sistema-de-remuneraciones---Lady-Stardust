--
-- PostgreSQL database dump
--

-- Dumped from database version 17.5 (Ubuntu 17.5-1.pgdg24.04+1)
-- Dumped by pg_dump version 17.5 (Ubuntu 17.5-1.pgdg24.04+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: mae_aportacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mae_aportacion (
    id_aportacion integer NOT NULL,
    nombre_aportacion character varying(100),
    descripcion character varying(250),
    tipo character varying(50),
    porcentaje double precision,
    monto_fijo double precision,
    estado boolean,
    usuario_creacion character varying(100),
    fecha_creacion timestamp without time zone,
    usuario_modificacion character varying(100),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.mae_aportacion OWNER TO postgres;

--
-- Name: mae_aportacion_id_aportacion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mae_aportacion_id_aportacion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mae_aportacion_id_aportacion_seq OWNER TO postgres;

--
-- Name: mae_aportacion_id_aportacion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mae_aportacion_id_aportacion_seq OWNED BY public.mae_aportacion.id_aportacion;


--
-- Name: mae_bonificacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mae_bonificacion (
    id_bonificacion integer NOT NULL,
    nombre_bonificacion character varying(100),
    descripcion character varying(250),
    tipo character varying(50),
    porcentaje double precision,
    monto_fijo double precision,
    estado boolean,
    usuario_creacion character varying(100),
    fecha_creacion timestamp without time zone,
    usuario_modificacion character varying(100),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.mae_bonificacion OWNER TO postgres;

--
-- Name: mae_bonificacion_id_bonificacion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mae_bonificacion_id_bonificacion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mae_bonificacion_id_bonificacion_seq OWNER TO postgres;

--
-- Name: mae_bonificacion_id_bonificacion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mae_bonificacion_id_bonificacion_seq OWNED BY public.mae_bonificacion.id_bonificacion;


--
-- Name: mae_deduccion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mae_deduccion (
    id_deduccion integer NOT NULL,
    nombre_deduccion character varying(100),
    descripcion character varying(250),
    tipo character varying(50),
    porcentaje double precision,
    monto_fijo double precision,
    estado boolean,
    usuario_creacion character varying(100),
    fecha_creacion timestamp without time zone,
    usuario_modificacion character varying(100),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.mae_deduccion OWNER TO postgres;

--
-- Name: mae_deduccion_id_deduccion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mae_deduccion_id_deduccion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mae_deduccion_id_deduccion_seq OWNER TO postgres;

--
-- Name: mae_deduccion_id_deduccion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mae_deduccion_id_deduccion_seq OWNED BY public.mae_deduccion.id_deduccion;


--
-- Name: mae_empleado; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mae_empleado (
    id_empleado integer NOT NULL,
    nombres character varying(100),
    apellidos character varying(100),
    direccion character varying(150),
    fecha_ingreso date,
    fecha_cese date,
    fecha_nacimiento date,
    genero character varying(20),
    sueldo_base double precision,
    tipo_trabajador character varying(50),
    tipo_contrato character varying(50),
    regimen_laboral character varying(50),
    situacion character varying(50),
    cusp character varying(50),
    regimen_pensionario character varying(50),
    seguro_salud character varying(50),
    sctr boolean,
    tipo_pago character varying(50),
    tipo_remuneracion character varying(50),
    activo boolean,
    numero_documento character varying(20),
    id_tipo_documento integer,
    id_puesto integer,
    id_local integer,
    id_empresa integer,
    estado boolean,
    usuario_creacion character varying(100),
    fecha_creacion timestamp without time zone,
    usuario_modificacion character varying(100),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.mae_empleado OWNER TO postgres;

--
-- Name: mae_empleado_id_empleado_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mae_empleado_id_empleado_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mae_empleado_id_empleado_seq OWNER TO postgres;

--
-- Name: mae_empleado_id_empleado_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mae_empleado_id_empleado_seq OWNED BY public.mae_empleado.id_empleado;


--
-- Name: mae_empresa; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mae_empresa (
    id_empresa integer NOT NULL,
    razon_social character varying(100),
    ruc character varying(20),
    direccion character varying(150),
    telefono character varying(20),
    correo_electronico character varying(100),
    tipo_empleador character varying(50),
    representante_legal character varying(100),
    logo_empresa character varying(150),
    estado boolean,
    usuario_creacion character varying(100),
    fecha_creacion timestamp without time zone,
    usuario_modificacion character varying(100),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.mae_empresa OWNER TO postgres;

--
-- Name: mae_empresa_id_empresa_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mae_empresa_id_empresa_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mae_empresa_id_empresa_seq OWNER TO postgres;

--
-- Name: mae_empresa_id_empresa_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mae_empresa_id_empresa_seq OWNED BY public.mae_empresa.id_empresa;


--
-- Name: mae_ingreso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mae_ingreso (
    id_ingreso integer NOT NULL,
    nombre_ingreso character varying(100),
    descripcion character varying(250),
    tipo character varying(50),
    porcentaje double precision,
    monto_fijo double precision,
    estado boolean,
    usuario_creacion character varying(100),
    fecha_creacion timestamp without time zone,
    usuario_modificacion character varying(100),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.mae_ingreso OWNER TO postgres;

--
-- Name: mae_ingreso_id_ingreso_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mae_ingreso_id_ingreso_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mae_ingreso_id_ingreso_seq OWNER TO postgres;

--
-- Name: mae_ingreso_id_ingreso_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mae_ingreso_id_ingreso_seq OWNED BY public.mae_ingreso.id_ingreso;


--
-- Name: mae_local; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mae_local (
    id_local integer NOT NULL,
    nombre_local character varying(100),
    direccion character varying(150),
    telefono character varying(20),
    estado boolean,
    usuario_creacion character varying(100),
    fecha_creacion timestamp without time zone,
    usuario_modificacion character varying(100),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.mae_local OWNER TO postgres;

--
-- Name: mae_local_id_local_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mae_local_id_local_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mae_local_id_local_seq OWNER TO postgres;

--
-- Name: mae_local_id_local_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mae_local_id_local_seq OWNED BY public.mae_local.id_local;


--
-- Name: mae_puesto; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mae_puesto (
    id_puesto integer NOT NULL,
    nombre_puesto character varying(100),
    descripcion character varying(250),
    sueldo_minimo double precision,
    sueldo_maximo double precision,
    codigo_sunat character varying(20),
    estado boolean,
    usuario_creacion character varying(100),
    fecha_creacion timestamp without time zone,
    usuario_modificacion character varying(100),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.mae_puesto OWNER TO postgres;

--
-- Name: mae_puesto_id_puesto_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mae_puesto_id_puesto_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mae_puesto_id_puesto_seq OWNER TO postgres;

--
-- Name: mae_puesto_id_puesto_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mae_puesto_id_puesto_seq OWNED BY public.mae_puesto.id_puesto;


--
-- Name: mae_rol; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mae_rol (
    id_rol integer NOT NULL,
    nombre_rol character varying(50),
    descripcion_rol character varying(150),
    estado boolean,
    usuario_creacion character varying(100),
    fecha_creacion timestamp without time zone,
    usuario_modificacion character varying(100),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.mae_rol OWNER TO postgres;

--
-- Name: mae_rol_id_rol_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mae_rol_id_rol_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mae_rol_id_rol_seq OWNER TO postgres;

--
-- Name: mae_rol_id_rol_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mae_rol_id_rol_seq OWNED BY public.mae_rol.id_rol;


--
-- Name: mae_tipodocumento; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mae_tipodocumento (
    id_tipo_documento integer NOT NULL,
    nombre_tipo character varying(50),
    descripcion character varying(100),
    estado boolean,
    usuario_creacion character varying(100),
    fecha_creacion timestamp without time zone,
    usuario_modificacion character varying(100),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.mae_tipodocumento OWNER TO postgres;

--
-- Name: mae_tipodocumento_id_tipo_documento_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mae_tipodocumento_id_tipo_documento_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mae_tipodocumento_id_tipo_documento_seq OWNER TO postgres;

--
-- Name: mae_tipodocumento_id_tipo_documento_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mae_tipodocumento_id_tipo_documento_seq OWNED BY public.mae_tipodocumento.id_tipo_documento;


--
-- Name: mae_usuario; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.mae_usuario (
    id_usuario integer NOT NULL,
    correo_electronico character varying(100),
    contrasena character varying(150),
    id_rol integer,
    id_empleado integer,
    id_empresa integer,
    estado boolean,
    usuario_creacion character varying(100),
    fecha_creacion timestamp without time zone,
    usuario_modificacion character varying(100),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.mae_usuario OWNER TO postgres;

--
-- Name: mae_usuario_id_usuario_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.mae_usuario_id_usuario_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.mae_usuario_id_usuario_seq OWNER TO postgres;

--
-- Name: mae_usuario_id_usuario_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.mae_usuario_id_usuario_seq OWNED BY public.mae_usuario.id_usuario;


--
-- Name: trs_pago; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trs_pago (
    id_pago integer NOT NULL,
    id_empleado integer,
    periodo_pago character varying(20),
    fecha_pago date,
    monto_pagado double precision,
    metodo_pago character varying(50),
    tipo_pago character varying(50),
    observaciones character varying(250),
    total_ingresos double precision,
    total_descuentos double precision,
    total_aportaciones double precision,
    total_neto double precision,
    estado boolean,
    usuario_creacion character varying(100),
    fecha_creacion timestamp without time zone,
    usuario_modificacion character varying(100),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.trs_pago OWNER TO postgres;

--
-- Name: trs_pago_id_pago_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.trs_pago_id_pago_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.trs_pago_id_pago_seq OWNER TO postgres;

--
-- Name: trs_pago_id_pago_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.trs_pago_id_pago_seq OWNED BY public.trs_pago.id_pago;


--
-- Name: trs_pagoaportacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trs_pagoaportacion (
    id_pago_aportacion integer NOT NULL,
    id_pago integer,
    id_aportacion integer,
    monto double precision,
    estado boolean,
    usuario_creacion character varying(100),
    fecha_creacion timestamp without time zone,
    usuario_modificacion character varying(100),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.trs_pagoaportacion OWNER TO postgres;

--
-- Name: trs_pagoaportacion_id_pago_aportacion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.trs_pagoaportacion_id_pago_aportacion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.trs_pagoaportacion_id_pago_aportacion_seq OWNER TO postgres;

--
-- Name: trs_pagoaportacion_id_pago_aportacion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.trs_pagoaportacion_id_pago_aportacion_seq OWNED BY public.trs_pagoaportacion.id_pago_aportacion;


--
-- Name: trs_pagobonificacion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trs_pagobonificacion (
    id_pago_bonificacion integer NOT NULL,
    id_pago integer,
    id_bonificacion integer,
    monto double precision,
    estado boolean,
    usuario_creacion character varying(100),
    fecha_creacion timestamp without time zone,
    usuario_modificacion character varying(100),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.trs_pagobonificacion OWNER TO postgres;

--
-- Name: trs_pagobonificacion_id_pago_bonificacion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.trs_pagobonificacion_id_pago_bonificacion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.trs_pagobonificacion_id_pago_bonificacion_seq OWNER TO postgres;

--
-- Name: trs_pagobonificacion_id_pago_bonificacion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.trs_pagobonificacion_id_pago_bonificacion_seq OWNED BY public.trs_pagobonificacion.id_pago_bonificacion;


--
-- Name: trs_pagodeduccion; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trs_pagodeduccion (
    id_pago_deduccion integer NOT NULL,
    id_pago integer,
    id_deduccion integer,
    monto double precision,
    estado boolean,
    usuario_creacion character varying(100),
    fecha_creacion timestamp without time zone,
    usuario_modificacion character varying(100),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.trs_pagodeduccion OWNER TO postgres;

--
-- Name: trs_pagodeduccion_id_pago_deduccion_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.trs_pagodeduccion_id_pago_deduccion_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.trs_pagodeduccion_id_pago_deduccion_seq OWNER TO postgres;

--
-- Name: trs_pagodeduccion_id_pago_deduccion_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.trs_pagodeduccion_id_pago_deduccion_seq OWNED BY public.trs_pagodeduccion.id_pago_deduccion;


--
-- Name: trs_pagoingreso; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.trs_pagoingreso (
    id_pago_ingreso integer NOT NULL,
    id_pago integer,
    id_ingreso integer,
    monto double precision,
    estado boolean,
    usuario_creacion character varying(100),
    fecha_creacion timestamp without time zone,
    usuario_modificacion character varying(100),
    fecha_modificacion timestamp without time zone
);


ALTER TABLE public.trs_pagoingreso OWNER TO postgres;

--
-- Name: trs_pagoingreso_id_pago_ingreso_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.trs_pagoingreso_id_pago_ingreso_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.trs_pagoingreso_id_pago_ingreso_seq OWNER TO postgres;

--
-- Name: trs_pagoingreso_id_pago_ingreso_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.trs_pagoingreso_id_pago_ingreso_seq OWNED BY public.trs_pagoingreso.id_pago_ingreso;


--
-- Name: mae_aportacion id_aportacion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_aportacion ALTER COLUMN id_aportacion SET DEFAULT nextval('public.mae_aportacion_id_aportacion_seq'::regclass);


--
-- Name: mae_bonificacion id_bonificacion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_bonificacion ALTER COLUMN id_bonificacion SET DEFAULT nextval('public.mae_bonificacion_id_bonificacion_seq'::regclass);


--
-- Name: mae_deduccion id_deduccion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_deduccion ALTER COLUMN id_deduccion SET DEFAULT nextval('public.mae_deduccion_id_deduccion_seq'::regclass);


--
-- Name: mae_empleado id_empleado; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_empleado ALTER COLUMN id_empleado SET DEFAULT nextval('public.mae_empleado_id_empleado_seq'::regclass);


--
-- Name: mae_empresa id_empresa; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_empresa ALTER COLUMN id_empresa SET DEFAULT nextval('public.mae_empresa_id_empresa_seq'::regclass);


--
-- Name: mae_ingreso id_ingreso; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_ingreso ALTER COLUMN id_ingreso SET DEFAULT nextval('public.mae_ingreso_id_ingreso_seq'::regclass);


--
-- Name: mae_local id_local; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_local ALTER COLUMN id_local SET DEFAULT nextval('public.mae_local_id_local_seq'::regclass);


--
-- Name: mae_puesto id_puesto; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_puesto ALTER COLUMN id_puesto SET DEFAULT nextval('public.mae_puesto_id_puesto_seq'::regclass);


--
-- Name: mae_rol id_rol; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_rol ALTER COLUMN id_rol SET DEFAULT nextval('public.mae_rol_id_rol_seq'::regclass);


--
-- Name: mae_tipodocumento id_tipo_documento; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_tipodocumento ALTER COLUMN id_tipo_documento SET DEFAULT nextval('public.mae_tipodocumento_id_tipo_documento_seq'::regclass);


--
-- Name: mae_usuario id_usuario; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_usuario ALTER COLUMN id_usuario SET DEFAULT nextval('public.mae_usuario_id_usuario_seq'::regclass);


--
-- Name: trs_pago id_pago; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trs_pago ALTER COLUMN id_pago SET DEFAULT nextval('public.trs_pago_id_pago_seq'::regclass);


--
-- Name: trs_pagoaportacion id_pago_aportacion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trs_pagoaportacion ALTER COLUMN id_pago_aportacion SET DEFAULT nextval('public.trs_pagoaportacion_id_pago_aportacion_seq'::regclass);


--
-- Name: trs_pagobonificacion id_pago_bonificacion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trs_pagobonificacion ALTER COLUMN id_pago_bonificacion SET DEFAULT nextval('public.trs_pagobonificacion_id_pago_bonificacion_seq'::regclass);


--
-- Name: trs_pagodeduccion id_pago_deduccion; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trs_pagodeduccion ALTER COLUMN id_pago_deduccion SET DEFAULT nextval('public.trs_pagodeduccion_id_pago_deduccion_seq'::regclass);


--
-- Name: trs_pagoingreso id_pago_ingreso; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trs_pagoingreso ALTER COLUMN id_pago_ingreso SET DEFAULT nextval('public.trs_pagoingreso_id_pago_ingreso_seq'::regclass);


--
-- Data for Name: mae_aportacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mae_aportacion (id_aportacion, nombre_aportacion, descripcion, tipo, porcentaje, monto_fijo, estado, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion) FROM stdin;
\.


--
-- Data for Name: mae_bonificacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mae_bonificacion (id_bonificacion, nombre_bonificacion, descripcion, tipo, porcentaje, monto_fijo, estado, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion) FROM stdin;
\.


--
-- Data for Name: mae_deduccion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mae_deduccion (id_deduccion, nombre_deduccion, descripcion, tipo, porcentaje, monto_fijo, estado, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion) FROM stdin;
\.


--
-- Data for Name: mae_empleado; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mae_empleado (id_empleado, nombres, apellidos, direccion, fecha_ingreso, fecha_cese, fecha_nacimiento, genero, sueldo_base, tipo_trabajador, tipo_contrato, regimen_laboral, situacion, cusp, regimen_pensionario, seguro_salud, sctr, tipo_pago, tipo_remuneracion, activo, numero_documento, id_tipo_documento, id_puesto, id_local, id_empresa, estado, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion) FROM stdin;
1	Andry Fabian	Caceres Quispe	Cayma, Arequipa	2025-06-25	\N	2006-07-01	Masculino	0	Empleado	Indeterminado	General	Activo	\N	\N	\N	t	Transferencia	\N	t	60783379	1	1	1	1	t	andrycaceres2006@gmail.com	2025-06-25 22:40:56.281904	\N	\N
\.


--
-- Data for Name: mae_empresa; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mae_empresa (id_empresa, razon_social, ruc, direccion, telefono, correo_electronico, tipo_empleador, representante_legal, logo_empresa, estado, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion) FROM stdin;
1	Lady Stardust		Arequipa, Perú, Panorámico	916947244	\N	Privado	Mika Bowie	\N	t	andry.caceres@estudiante.ucsm.edu.pe	2025-06-25 19:17:50.208766	\N	\N
\.


--
-- Data for Name: mae_ingreso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mae_ingreso (id_ingreso, nombre_ingreso, descripcion, tipo, porcentaje, monto_fijo, estado, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion) FROM stdin;
\.


--
-- Data for Name: mae_local; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mae_local (id_local, nombre_local, direccion, telefono, estado, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion) FROM stdin;
1	Sede Panorámico 341	C.C Panorámico Of 341, Arequipa	916947244	t	andrycaceres2006@gmail.com	2025-06-25 19:44:56.338177	\N	\N
2	Sede Panorámico 221	C.C Panorámico Of 221, Arequipa	916947244	t	andrycaceres2006@gmail.com	2025-06-25 19:44:56.338177	\N	\N
\.


--
-- Data for Name: mae_puesto; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mae_puesto (id_puesto, nombre_puesto, descripcion, sueldo_minimo, sueldo_maximo, codigo_sunat, estado, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion) FROM stdin;
1	Ingeniero de Sistemas	Responsable de los sistemas	0	0	10607833791	t	andrycaceres2006@gmail.com	2025-06-25 21:41:28.399575	\N	\N
\.


--
-- Data for Name: mae_rol; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mae_rol (id_rol, nombre_rol, descripcion_rol, estado, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion) FROM stdin;
1	Administrador de Sistemas	Permiso más alto para gestión y control de sistemas informáticos	t	andrycaceres2006@gmail.com	2025-06-25 21:46:18.666859	\N	\N
\.


--
-- Data for Name: mae_tipodocumento; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mae_tipodocumento (id_tipo_documento, nombre_tipo, descripcion, estado, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion) FROM stdin;
1	DNI	Documento Nacional de Identidad	t	andrycaceres2006@gmail.com	2025-06-25 19:41:06.170216	\N	\N
\.


--
-- Data for Name: mae_usuario; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.mae_usuario (id_usuario, correo_electronico, contrasena, id_rol, id_empleado, id_empresa, estado, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion) FROM stdin;
1	andrycaceres2006@gmail.com	Elmomer0123_XD	1	1	1	t	andrycaceres2006@gmail.com	2025-06-25 22:46:41.72174	\N	\N
\.


--
-- Data for Name: trs_pago; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trs_pago (id_pago, id_empleado, periodo_pago, fecha_pago, monto_pagado, metodo_pago, tipo_pago, observaciones, total_ingresos, total_descuentos, total_aportaciones, total_neto, estado, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion) FROM stdin;
\.


--
-- Data for Name: trs_pagoaportacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trs_pagoaportacion (id_pago_aportacion, id_pago, id_aportacion, monto, estado, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion) FROM stdin;
\.


--
-- Data for Name: trs_pagobonificacion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trs_pagobonificacion (id_pago_bonificacion, id_pago, id_bonificacion, monto, estado, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion) FROM stdin;
\.


--
-- Data for Name: trs_pagodeduccion; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trs_pagodeduccion (id_pago_deduccion, id_pago, id_deduccion, monto, estado, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion) FROM stdin;
\.


--
-- Data for Name: trs_pagoingreso; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.trs_pagoingreso (id_pago_ingreso, id_pago, id_ingreso, monto, estado, usuario_creacion, fecha_creacion, usuario_modificacion, fecha_modificacion) FROM stdin;
\.


--
-- Name: mae_aportacion_id_aportacion_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mae_aportacion_id_aportacion_seq', 1, false);


--
-- Name: mae_bonificacion_id_bonificacion_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mae_bonificacion_id_bonificacion_seq', 1, false);


--
-- Name: mae_deduccion_id_deduccion_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mae_deduccion_id_deduccion_seq', 1, false);


--
-- Name: mae_empleado_id_empleado_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mae_empleado_id_empleado_seq', 1, true);


--
-- Name: mae_empresa_id_empresa_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mae_empresa_id_empresa_seq', 1, true);


--
-- Name: mae_ingreso_id_ingreso_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mae_ingreso_id_ingreso_seq', 1, false);


--
-- Name: mae_local_id_local_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mae_local_id_local_seq', 2, true);


--
-- Name: mae_puesto_id_puesto_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mae_puesto_id_puesto_seq', 1, true);


--
-- Name: mae_rol_id_rol_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mae_rol_id_rol_seq', 1, true);


--
-- Name: mae_tipodocumento_id_tipo_documento_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mae_tipodocumento_id_tipo_documento_seq', 1, true);


--
-- Name: mae_usuario_id_usuario_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.mae_usuario_id_usuario_seq', 1, true);


--
-- Name: trs_pago_id_pago_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.trs_pago_id_pago_seq', 1, false);


--
-- Name: trs_pagoaportacion_id_pago_aportacion_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.trs_pagoaportacion_id_pago_aportacion_seq', 1, false);


--
-- Name: trs_pagobonificacion_id_pago_bonificacion_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.trs_pagobonificacion_id_pago_bonificacion_seq', 1, false);


--
-- Name: trs_pagodeduccion_id_pago_deduccion_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.trs_pagodeduccion_id_pago_deduccion_seq', 1, false);


--
-- Name: trs_pagoingreso_id_pago_ingreso_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.trs_pagoingreso_id_pago_ingreso_seq', 1, false);


--
-- Name: mae_usuario mae_usuario_correo_electronico_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_usuario
    ADD CONSTRAINT mae_usuario_correo_electronico_key UNIQUE (correo_electronico);


--
-- Name: mae_aportacion pk_mae_aportacion; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_aportacion
    ADD CONSTRAINT pk_mae_aportacion PRIMARY KEY (id_aportacion);


--
-- Name: mae_bonificacion pk_mae_bonificacion; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_bonificacion
    ADD CONSTRAINT pk_mae_bonificacion PRIMARY KEY (id_bonificacion);


--
-- Name: mae_deduccion pk_mae_deduccion; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_deduccion
    ADD CONSTRAINT pk_mae_deduccion PRIMARY KEY (id_deduccion);


--
-- Name: mae_empleado pk_mae_empleado; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_empleado
    ADD CONSTRAINT pk_mae_empleado PRIMARY KEY (id_empleado);


--
-- Name: mae_empresa pk_mae_empresa; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_empresa
    ADD CONSTRAINT pk_mae_empresa PRIMARY KEY (id_empresa);


--
-- Name: mae_ingreso pk_mae_ingreso; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_ingreso
    ADD CONSTRAINT pk_mae_ingreso PRIMARY KEY (id_ingreso);


--
-- Name: mae_local pk_mae_local; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_local
    ADD CONSTRAINT pk_mae_local PRIMARY KEY (id_local);


--
-- Name: mae_puesto pk_mae_puesto; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_puesto
    ADD CONSTRAINT pk_mae_puesto PRIMARY KEY (id_puesto);


--
-- Name: mae_rol pk_mae_rol; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_rol
    ADD CONSTRAINT pk_mae_rol PRIMARY KEY (id_rol);


--
-- Name: mae_tipodocumento pk_mae_tipodocumento; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_tipodocumento
    ADD CONSTRAINT pk_mae_tipodocumento PRIMARY KEY (id_tipo_documento);


--
-- Name: mae_usuario pk_mae_usuario; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_usuario
    ADD CONSTRAINT pk_mae_usuario PRIMARY KEY (id_usuario);


--
-- Name: trs_pago pk_trs_pago; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trs_pago
    ADD CONSTRAINT pk_trs_pago PRIMARY KEY (id_pago);


--
-- Name: trs_pagoaportacion pk_trs_pagoaportacion; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trs_pagoaportacion
    ADD CONSTRAINT pk_trs_pagoaportacion PRIMARY KEY (id_pago_aportacion);


--
-- Name: trs_pagobonificacion pk_trs_pagobonificacion; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trs_pagobonificacion
    ADD CONSTRAINT pk_trs_pagobonificacion PRIMARY KEY (id_pago_bonificacion);


--
-- Name: trs_pagodeduccion pk_trs_pagodeduccion; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trs_pagodeduccion
    ADD CONSTRAINT pk_trs_pagodeduccion PRIMARY KEY (id_pago_deduccion);


--
-- Name: trs_pagoingreso pk_trs_pagoingreso; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trs_pagoingreso
    ADD CONSTRAINT pk_trs_pagoingreso PRIMARY KEY (id_pago_ingreso);


--
-- Name: mae_empleado fk_empleado_empresa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_empleado
    ADD CONSTRAINT fk_empleado_empresa FOREIGN KEY (id_empresa) REFERENCES public.mae_empresa(id_empresa);


--
-- Name: mae_empleado fk_empleado_local; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_empleado
    ADD CONSTRAINT fk_empleado_local FOREIGN KEY (id_local) REFERENCES public.mae_local(id_local);


--
-- Name: mae_empleado fk_empleado_puesto; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_empleado
    ADD CONSTRAINT fk_empleado_puesto FOREIGN KEY (id_puesto) REFERENCES public.mae_puesto(id_puesto);


--
-- Name: mae_empleado fk_empleado_tipodocumento; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_empleado
    ADD CONSTRAINT fk_empleado_tipodocumento FOREIGN KEY (id_tipo_documento) REFERENCES public.mae_tipodocumento(id_tipo_documento);


--
-- Name: trs_pago fk_trs_pago_mae_empleado; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trs_pago
    ADD CONSTRAINT fk_trs_pago_mae_empleado FOREIGN KEY (id_empleado) REFERENCES public.mae_empleado(id_empleado);


--
-- Name: trs_pagoaportacion fk_trs_pagoaportacion_mae_aportacion; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trs_pagoaportacion
    ADD CONSTRAINT fk_trs_pagoaportacion_mae_aportacion FOREIGN KEY (id_aportacion) REFERENCES public.mae_aportacion(id_aportacion);


--
-- Name: trs_pagoaportacion fk_trs_pagoaportacion_trs_pago; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trs_pagoaportacion
    ADD CONSTRAINT fk_trs_pagoaportacion_trs_pago FOREIGN KEY (id_pago) REFERENCES public.trs_pago(id_pago);


--
-- Name: trs_pagobonificacion fk_trs_pagobonificacion_mae_bonificacion; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trs_pagobonificacion
    ADD CONSTRAINT fk_trs_pagobonificacion_mae_bonificacion FOREIGN KEY (id_bonificacion) REFERENCES public.mae_bonificacion(id_bonificacion);


--
-- Name: trs_pagobonificacion fk_trs_pagobonificacion_trs_pago; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trs_pagobonificacion
    ADD CONSTRAINT fk_trs_pagobonificacion_trs_pago FOREIGN KEY (id_pago) REFERENCES public.trs_pago(id_pago);


--
-- Name: trs_pagodeduccion fk_trs_pagodeduccion_mae_deduccion; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trs_pagodeduccion
    ADD CONSTRAINT fk_trs_pagodeduccion_mae_deduccion FOREIGN KEY (id_deduccion) REFERENCES public.mae_deduccion(id_deduccion);


--
-- Name: trs_pagodeduccion fk_trs_pagodeduccion_trs_pago; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trs_pagodeduccion
    ADD CONSTRAINT fk_trs_pagodeduccion_trs_pago FOREIGN KEY (id_pago) REFERENCES public.trs_pago(id_pago);


--
-- Name: trs_pagoingreso fk_trs_pagoingreso_mae_ingreso; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trs_pagoingreso
    ADD CONSTRAINT fk_trs_pagoingreso_mae_ingreso FOREIGN KEY (id_ingreso) REFERENCES public.mae_ingreso(id_ingreso);


--
-- Name: trs_pagoingreso fk_trs_pagoingreso_trs_pago; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.trs_pagoingreso
    ADD CONSTRAINT fk_trs_pagoingreso_trs_pago FOREIGN KEY (id_pago) REFERENCES public.trs_pago(id_pago);


--
-- Name: mae_usuario fk_usuario_empleado; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_usuario
    ADD CONSTRAINT fk_usuario_empleado FOREIGN KEY (id_empleado) REFERENCES public.mae_empleado(id_empleado);


--
-- Name: mae_usuario fk_usuario_empresa; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_usuario
    ADD CONSTRAINT fk_usuario_empresa FOREIGN KEY (id_empresa) REFERENCES public.mae_empresa(id_empresa);


--
-- Name: mae_usuario fk_usuario_rol; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.mae_usuario
    ADD CONSTRAINT fk_usuario_rol FOREIGN KEY (id_rol) REFERENCES public.mae_rol(id_rol);


--
-- PostgreSQL database dump complete
--

